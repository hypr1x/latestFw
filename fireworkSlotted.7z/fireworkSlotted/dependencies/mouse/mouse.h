#pragma once
#ifdef __cplusplus
extern "C" {
#endif

	typedef int BOOL;

	BOOL mouse_open(void);
	void mouse_close(void);
	void mouse_move(char button, char x, char y, char wheel);

#ifdef __cplusplus
}
#endif