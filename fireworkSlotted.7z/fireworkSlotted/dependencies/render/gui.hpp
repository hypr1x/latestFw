#pragma once
#include <dependencies/render/framework/utilities.hpp>
#include <dependencies/imgui/imgui.h>
#include <dependencies/imgui/imgui_impl_dx11.h>
#include <dependencies/imgui/imgui_impl_win32.h>
#include <dependencies/cipher/hash.hpp>
#include <dependencies/cipher/imports.hpp>
#include <dependencies/render/framework/burbank.hpp>
#include <dependencies/render/render.hpp>
#include <dependencies/render/elements.hpp>
#include <dependencies/vars/vars.hpp>

void renderGui() {

	ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));    // No spacing between items
	ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));    // No spacing between items
	ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(0, 0));  // No padding inside frames
	ImGui::SetNextWindowSize(ImVec2(400, 400));
	ImGui::Begin(hash_str("firework.private"), nullptr, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar);

	const char* text_firework = hash_str("firework ");
	const char* text_alpha = hash_str("private");
	ImVec4 color_firework = ImVec4(0.0f, 0.5f, 1.0f, 1.0f);

	// Calculate total width of the combined text
	ImVec2 text_firework_size = ImGui::CalcTextSize(text_firework);
	ImVec2 text_alpha_size = ImGui::CalcTextSize(text_alpha);
	float total_width = text_firework_size.x + ImGui::GetStyle().ItemSpacing.x + text_alpha_size.x;

	// Get the window's available width
	float window_width = 400;

	// Calculate starting position to center the text
	float start_pos_x = (window_width - total_width) / 2.0f;

	// Adjust the cursor position for centering
	ImGui::SetCursorPosX(start_pos_x);
	ImGui::SetCursorPosY(10);

	// Render the first text with color
	ImGui::PushStyleColor(ImGuiCol_Text, color_firework);
	ImGui::TextUnformatted(text_firework);
	ImGui::PopStyleColor();
	ImGui::SameLine();
	ImGui::Spacing();
	// Render the second text next to it
	ImGui::SameLine();
	ImGui::TextUnformatted(text_alpha);
	//ImGui::Separator();

	ImGui::PopFont();
	ImGui::PushFont(burbank);
	ImGui::SetCursorPosY(40);
	//ImGui::BeginChild("##navigation", ImVec2(500, 100), true);
	{
		// Define the size of each button
		ImVec2 button_size = ImVec2(400 / 3.0f, 30);

		ImVec4 active_button_color = ImVec4(8 / 255.0f, 8 / 255.0f, 8 / 255.0f, 1.0f);
		ImVec4 default_button_color = ImGui::GetStyleColorVec4(ImGuiCol_Button); // Default button color

		if (current_tab == 0) {
			ImGui::PushStyleColor(ImGuiCol_Button, active_button_color); // Change button color
		}

		if (ImGui::Button("Softaim", button_size)) {
			current_tab = 0; // Set the active tab
		}

		if (current_tab == 0) {
			ImGui::PopStyleColor(); // Restore the default color
		}
		ImGui::SameLine(); // Align next button horizontally
		// Calculate and draw centered text for "Softaim"
		/*ImVec2 softaim_text_size = ImGui::CalcTextSize(hash_str("Softaim"));
		ImVec2 softaim_text_pos = ImGui::GetItemRectMin();
		softaim_text_pos.x += (button_size.x - softaim_text_size.x) / 2.0f;
		softaim_text_pos.x += (button_size.x - softaim_text_size.x) / 4.0f;
		softaim_text_pos.y += (button_size.y - softaim_text_size.y) / 2.0f;
		ImGui::SetCursorScreenPos(softaim_text_pos);
		ImGui::TextUnformatted(hash_str("Softaim"));*/

		ImGui::SameLine(); // Align next button horizontally
		if (current_tab == 1) {
			ImGui::PushStyleColor(ImGuiCol_Button, active_button_color); // Change button color
		}
		// "Visuals" Button
		if (ImGui::Button("Visuals", button_size)) {
			current_tab = 1;
		}
		if (current_tab == 1) {
			ImGui::PopStyleColor(); // Restore the default color
		}
		ImGui::SameLine(); // Align next button horizontally
		//// Calculate and draw centered text for "Visuals"
		//ImVec2 visuals_text_size = ImGui::CalcTextSize(hash_str("Visuals"));
		//ImVec2 visuals_text_pos = ImGui::GetItemRectMin();
		//visuals_text_pos.x += (button_size.x - visuals_text_size.x) / 2.0f;
		//visuals_text_pos.y += (button_size.y - visuals_text_size.y) / 2.0f;
		//ImGui::SetCursorScreenPos(visuals_text_pos);
		//ImGui::TextUnformatted(hash_str("Visuals"));
		ImGui::SameLine(); // Align next button horizontally
		if (current_tab == 2) {
			ImGui::PushStyleColor(ImGuiCol_Button, active_button_color); // Change button color
		}
		// "Triggerbot" Button
		if (ImGui::Button("Config", button_size)) {
			current_tab = 2;
		}
		if (current_tab == 2) {
			ImGui::PopStyleColor(); // Restore the default color
		}// Align next button horizontally
		// Calculate and draw centered text for "Triggerbot"
		/*ImVec2 triggerbot_text_size = ImGui::CalcTextSize(hash_str("Triggerbot"));
		ImVec2 triggerbot_text_pos = ImGui::GetItemRectMin();
		triggerbot_text_pos.x += (button_size.x - triggerbot_text_size.x) / 2.0f;
		triggerbot_text_pos.y += (button_size.y - triggerbot_text_size.y) / 2.0f;
		ImGui::SetCursorScreenPos(triggerbot_text_pos);
		ImGui::TextUnformatted(hash_str("Triggerbot"));*/
	}
	//ImGui::EndChild();

	//ImGui::SameLine();

	//ImGui::BeginChild(hash_str("##retard"), ImVec2(500, 400), true);
	ImGui::SetCursorPosY(80);
	ImGui::PopStyleVar(3);
	{
		ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(10, 10));    // No spacing between items
		//ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(100, 10));    // No spacing between items
		//ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(10, 10));  // No padding inside frames
		if (current_tab == 0) {
			//ImGui::Text(hash_str("aim assist settings"));
			//ImGui::Separator();
			ImGui::Spacing();
			CustomToggle("Enable Softaim", &g_vars->aimbot.aimbotEnabled);
			ImGui::Spacing();
			//ImGui::Checkbox(hash_str("aim assist"), &g_vars->aimbot.enabled);
			//ImGui::Checkbox(hash_str("fov circle"), &g_vars->aimbot.drawing.fov);
			//ImGui::Checkbox(hash_str("prediction"), &g_vars->aimbot.prediction);

			customSlider(hash_str("Strength"), &g_vars->aimbot.smooth, 1, 30);
			customSlider(hash_str("Delay"), &g_vars->aimbot.delay, 1, 30000);
			customSlider(hash_str("Fov"), &g_vars->aimbot.fov, 1, 1920);
			ImGui::Spacing();
			CustomToggle("Aim Prediction", &g_vars->aimbot.aimprediction);
			ImGui::Spacing();
			customSlider(hash_str("Prediction Strength"), &g_vars->aimbot.predictionstrength, 1, 30);
			customSlider(hash_str("Humanizer"), &g_vars->aimbot.humanizer, 1, 10);
			if (ImGui::Combo("Aim Key", &g_vars->aimbot.aimKey, key_names, IM_ARRAYSIZE(key_names))) {
				// Optionally do something when the selection changes
				//std::cout << "Selected Key: " << key_names[selected_key] << std::endl;
			}
		}
		else if (current_tab == 1) {
			ImGui::Spacing();
			CustomToggle("Enable Visuals", &g_vars->visuals.visualsEnabled);
			ImGui::Spacing();
			CustomToggle("Enable Box Esp", &g_vars->visuals.boxEnabled);
			ImGui::Spacing();
			CustomToggle("Enable Directional Arrows", &g_vars->visuals.arrowsEnabled);
			ImGui::Spacing();
			CustomToggle("Enable Skeleton Esp", &g_vars->visuals.skeletonEnabled);
			ImGui::Spacing();
			CustomToggle("Enable Fov Circle", &g_vars->visuals.fovEnabled);
			ImGui::Spacing();
			customSlider(hash_str("skele thickness"), &g_vars->visuals.skeletonespthickness, 0.0f, 4.f);
			customSlider(hash_str("skele outline"), &g_vars->visuals.skelethicknessoutline, 0.0f, 4.f);
			//ImGui::Checkbox(hash_str("skeleton"), &g_vars->visuals.skeleton);
			//ImGui::Checkbox(hash_str("box"), &g_vars->visuals.box);
			//ImGui::Checkbox(hash_str("head"), &g_vars->visuals.head);
		}
		else if (current_tab == 2) {
			//ImGui::ColorPicker4("Main Color", (float*)&mainColorPicker);
			ImGui::ColorEdit4("Skeleton Color", (float*)&g_vars->colors.skeletonColor, ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_DisplayRGB | ImGuiColorEditFlags_NoPicker);

			ImGui::ColorEdit4("Box Color", (float*)&g_vars->colors.boxColor, ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_DisplayRGB | ImGuiColorEditFlags_NoPicker);

			ImGui::ColorEdit4("Distance Color", (float*)&g_vars->colors.distanceColor, ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_DisplayRGB | ImGuiColorEditFlags_NoPicker);

			ImGui::ColorEdit4("Outline Color", (float*)&g_vars->colors.outlineColor, ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_DisplayRGB | ImGuiColorEditFlags_NoPicker);
		}
		//else if (current_tab == 3) {
		//	ImGui::Text("config settings");
		//	ImGui::Separator();
		//}
		//else if (current_tab == 4)
		//{
		//	ImGui::Text("debug settings");
		//	ImGui::Separator();
		//	//ImGui::Checkbox(hash_str("debug teams"), &g_vars->visuals.team_id);
		//	//ImGui::Checkbox(hash_str("debug ranks"), &g_vars->visuals.rank);
		//	//ImGui::Checkbox(hash_str("debug usernames"), &g_vars->visuals.name);
		//}
	}
	//ImGui::EndChild();
	ImGui::PopStyleVar(2);
	ImGui::End();
				}