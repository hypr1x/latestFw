#pragma once
#include <windows.h>
#include <tlhelp32.h>
#include <iostream>
#include <numbers>
#include <string>
#include <thread>
#include <vector>
#include <mutex>
#include <utility>
#include <unordered_map>
#include <bit>
#include <chrono>
//#include <core/sdk/game.hpp>
#include <core/offsets/offsets.hpp>
#include <core/sdk/sdk.hpp>
#include <core/game/aimbot/aimbot.hpp>
#include <core/game/visuals/visuals.hpp>
#include <dependencies/driver/driver.hpp>
#include <core/engine/engine.hpp>

#include <dependencies/cipher/hash.hpp>
#include <dependencies/cipher/imports.hpp>

#include <dependencies/imgui/imgui_impl_dx11.h>
#include <dependencies/imgui/imgui_impl_win32.h>
#include <dependencies/imgui/imgui.h>

#include <dependencies/render/framework/burbank.hpp>
#include <dependencies/render/render.hpp>
#include <dependencies/render/gui.hpp>

#include <dependencies/vars/vars.hpp>
#include <dependencies/render/elements.hpp>
#include <dependencies/mouse/mouse.h>

