#pragma once
#include <dependencies/imgui/imgui.h>
#include <dependencies/imgui/imgui_impl_dx11.h>
#include <dependencies/imgui/imgui_impl_win32.h>
#include <dependencies/render/framework/utilities.hpp>

bool CustomToggle(const char* label, bool* v)
{
	ImGui::PushID(label);
	ImGui::NewLine();
	ImGui::SameLine(10.f);
	// Display text on the left
	ImGui::Text(label);

	// Move to the far right of the window
	float widthOfArea = ImGui::GetWindowWidth();
	ImGui::SameLine(widthOfArea - (10.f + ImGui::GetFrameHeight() * 2.2f));  // Adjust this to place the button far right

	// Now we calculate the button's size
	ImVec2 p = ImGui::GetCursorScreenPos();
	float height = ImGui::GetFrameHeight();
	float width = height * 2.2f;  // Width of the button (adjust as needed)

	// Colors
	ImU32 color_bg_on = ImGui::GetColorU32(ImVec4(0.0f, 0.5f, 1.0f, 1.0f));  // Green when ON
	ImU32 color_bg_off = ImGui::GetColorU32(ImVec4(30 / 255.0f, 30 / 255.0f, 30 / 255.0f, 1.0f)); // Red when OFF
	ImU32 color_knob = ImGui::GetColorU32(ImVec4(0.5f, 0.5f, 0.5f, 1.0f));   // White knob
	ImU32 color_knob_on = ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, 1.0f));   // White knob

	// Invisible button to create the clickable toggle area
	ImGui::InvisibleButton(label, ImVec2(width, height));
	bool clicked = ImGui::IsItemClicked();
	if (clicked)
		*v = !(*v); // Toggle state

	// Background of the toggle
	ImDrawList* draw_list = ImGui::GetWindowDrawList();
	draw_list->AddRectFilled(p, ImVec2(p.x + width, p.y + height), *v ? color_bg_on : color_bg_off, height * 0.5f);

	// Knob position
	float knob_radius = height * 0.4f;
	ImVec2 knob_pos = *v ? ImVec2(p.x + width - height * 0.5f, p.y + height * 0.5f) : ImVec2(p.x + height * 0.5f, p.y + height * 0.5f);

	// Draw the knob
	draw_list->AddCircleFilled(knob_pos, knob_radius, *v ? color_knob_on : color_knob);

	ImGui::PopID();

	return clicked;
}
void customSlider(const char* label, float* v, float v_min, float v_max) {
	ImGui::NewLine();
	ImGui::SameLine(10.f);
	ImGui::Text(label);

	float widthOfArea = ImGui::GetWindowWidth();

	float height = ImGui::GetFrameHeight();
	float width = height * 2.2f;
	char buffer[64];
	std::snprintf(buffer, sizeof(buffer), "%.2f", *v); // Format float with 2 decimal places

	// Get the text size for the formatted value
	ImVec2 textSize = ImGui::CalcTextSize(buffer);

	ImGui::SameLine(widthOfArea - (textSize.x - 30.f + ImGui::GetFrameHeight() * 2.2f));
	// Display the formatted value (without slider tooltip)

	ImGui::Text("%s", buffer);

	ImGui::PushItemWidth(-1);  // Use -1 to make the slider take up the full width of the window
	ImGui::SliderFloat(label, v, v_min, v_max, 0);
	ImGui::PopItemWidth();
}