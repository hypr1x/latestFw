#include <includes.hpp>

int main() {
	if (ioctl.start_service()) std::cout << "service successfully inited" << std::endl;
	else std::cout << "service could not start" << std::endl;
	if (!mouse_open()) {
		printf("[-] failed to open ghub macro driver\n");
		return 0;
	}

	//rzctl::init();
	ioctl.process_id = ioctl.attach("FortniteClient-Win64-Shipping.exe"); // FortniteClient-Win64-Shipping.exe
	ioctl.image_base = ioctl.get_image();
	std::cout << "image base : " << ioctl.image_base << "\n";
	ioctl.cr3 = ioctl.get_dtb();
	auto status = g_render->setup(hash_str(L"FortniteClient-Win64-Shipping.exe")); // FortniteClient-Win64-Shipping.exe
	if (status) {
		std::thread aimbotThread(aimbot);
		aimbotThread.detach();
		while (true) {
			g_render->tick();
		}
	}
}
