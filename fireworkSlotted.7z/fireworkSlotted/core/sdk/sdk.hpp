#pragma once
#include <core/offsets/offsets.hpp>
#include <dependencies/driver/driver.hpp>
#include <core/engine/engine.hpp>

#include <dependencies/cipher/hash.hpp>
#include <dependencies/cipher/imports.hpp>

#include <dependencies/imgui/imgui_impl_dx11.h>
#include <dependencies/imgui/imgui_impl_win32.h>

#include <dependencies/render/framework/burbank.hpp>
#include <dependencies/render/render.hpp>

#include <dependencies/vars/vars.hpp>
#include <dependencies/render/elements.hpp>
struct CameraInfo
{
	Vector3 location;
	Vector3 rotation;
	float fov;
};
CameraInfo viewInfo;

namespace sdk {
	namespace screen {
		extern Vector2 w2s(Vector3 WorldLocation)
		{

			D3DMATRIX tempMatrix = Matrix(viewInfo.rotation);
			Vector3 vAxisX = Vector3(tempMatrix.m[0][0], tempMatrix.m[0][1], tempMatrix.m[0][2]);
			Vector3 vAxisY = Vector3(tempMatrix.m[1][0], tempMatrix.m[1][1], tempMatrix.m[1][2]);
			Vector3 vAxisZ = Vector3(tempMatrix.m[2][0], tempMatrix.m[2][1], tempMatrix.m[2][2]);
			Vector3 vDelta = WorldLocation - viewInfo.location;
			Vector3 vTransformed = Vector3(vDelta.Dot(vAxisY), vDelta.Dot(vAxisZ), vDelta.Dot(vAxisX));
			if (vTransformed.z < 1.f)
				vTransformed.z = 1.f;

			return Vector2((1920 / 2.0f) + vTransformed.x * (((1920 / 2.0f) / tanf(viewInfo.fov * (float)m_pi / 360.f))) / vTransformed.z, (1080 / 2.0f) - vTransformed.y * (((1920 / 2.0f) / tanf(viewInfo.fov * (float)m_pi / 360.f))) / vTransformed.z);
		}
		extern Vector3 prediction(Vector3 target, Vector3 velocity, float projectile_speed, float gravity_scale, float distance)
		{
			//std::cout << projectile_speed << std::endl;
			//std::cout << gravity_scale << std::endl;
			//std::cout << target.z << std::endl;
			Vector3 newPos = target;
			float time = distance / (projectile_speed / 100);
			newPos.x += velocity.x * time;
			newPos.y += velocity.y * time;
			newPos.z += velocity.z * time;

			float gravity = std::fabs(-980.0f * gravity_scale) * 0.5f * time * time;
			newPos.z += gravity;
			//newPos.z += 1000;
			//std::cout << target.z << std::endl;

			return newPos;
		}
	};
	namespace bone {
		Vector3 bone_position(uintptr_t bone_array, unsigned long long bone_id, FTransform component_to_world)
		{
			FTransform bone_transform = ioctl.read<FTransform>(bone_array + (bone_id * 0x60));
			D3DMATRIX head_pos_matrix = MatrixMultiplication(bone_transform.ToMatrixWithScale(), component_to_world.ToMatrixWithScale());
			return Vector3(head_pos_matrix._41, head_pos_matrix._42, head_pos_matrix._43);
		}
		uintptr_t get_bone_array(uintptr_t mesh)
		{
			uintptr_t boneArray = ioctl.read<uintptr_t>(mesh + offsets->BoneArray);
			if (!util->is_valid(boneArray)) boneArray = ioctl.read<uintptr_t>(mesh + offsets->BoneArray + 0x10);
			if (!util->is_valid(boneArray)) return 0;
			return boneArray;
		}
	};
	namespace text {
		typedef unsigned int uint;
		typedef unsigned char uchar;
		typedef unsigned short ushort;
		typedef unsigned long ulong;

		typedef          char   int8;
		typedef   signed char   sint8;
		typedef unsigned char   uint8;
		typedef          short  int16;
		typedef   signed short  sint16;
		typedef unsigned short  uint16;
		typedef          int    int32;
		typedef   signed int    sint32;
		typedef unsigned int    uint32;

#define _BYTE  uint8
#define _WORD  uint16
#define _DWORD uint32
#define _QWORD uint64

		__forceinline std::string username(__int64 player)
		{
			//int xa = 0;
			//while (true) {
			//	//xa = xa + 4;
			//	__int64 Name = ioctl.read<__int64>(player + 2768);
			//	if (Name == 0 || xa > 1000000) continue;
			//	int Length = ioctl.read<int>(Name + 16i64);
			//	__int64 v6 = Length;
			//	//if (Length == 0 || Length > 200 || Length < 0) continue;
			//	//if (Length == 15) {
			//	//	std::cout << Length << std::endl;
			//	//	std::cout << xa << std::endl;
			//	//}
			//	//continue;
			//	if (!v6) continue;
			//	uintptr_t Data = ioctl.read<__int64>(Name + 8);
			//	if (!Data) continue;
			//	wchar_t* NameBuffer = new wchar_t[Length];
			//	ioctl.read_physical((PVOID)Data, NameBuffer, (Length * 2));
			//	char v21;
			//	int v22;
			//	int i;
			//	int v25;
			//	_WORD* v23;
			//	v21 = v6 - 1;
			//	if (!(_DWORD)v6)
			//		v21 = 0;
			//	v22 = 0;
			//	v23 = (_WORD*)NameBuffer;
			//	for (i = (v21) & 3; ; *v23++ += i & 7)
			//	{
			//		v25 = v6 - 1;
			//		if (!(_DWORD)v6)
			//			v25 = 0;
			//		if (v22 >= v25)
			//			break;
			//		i += 3;
			//		++v22;
			//	}
			//	std::wstring Temp{ NameBuffer };
			//	delete[] NameBuffer;
			//	std::cout << std::string(Temp.begin(), Temp.end());
			//	while (true) {}
			//}

			__int64 Name = ioctl.read<__int64>(player + 2768);
			if (!Name) return std::string("bot/AI");
			int Length = ioctl.read<int>(Name + 16i64);
			__int64 v6 = Length;
			if (!v6) return std::string("bot/AI");
			uintptr_t Data = ioctl.read<__int64>(Name + 8);
			if (!Data) return std::string("bot/AI");
			wchar_t* NameBuffer = new wchar_t[Length];
			ioctl.read_physical((PVOID)Data, NameBuffer, (Length * 2));

			char v21;
			int v22;
			int i;
			int v25;
			_WORD* v23;

			v21 = v6 - 1;
			if (!(_DWORD)v6)
				v21 = 0;
			v22 = 0;
			v23 = (_WORD*)NameBuffer;
			for (i = (v21) & 3; ; *v23++ += i & 7)
			{
				v25 = v6 - 1;
				if (!(_DWORD)v6)
					v25 = 0;
				if (v22 >= v25)
					break;
				i += 3;
				++v22;
			}

			std::wstring Temp{ NameBuffer };
			delete[] NameBuffer;
			return std::string(Temp.begin(), Temp.end());
		}
	};
};