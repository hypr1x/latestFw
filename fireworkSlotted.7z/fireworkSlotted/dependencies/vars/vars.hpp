#pragma once
#include <windows.h>
#include <iostream>
#include <dependencies/imgui/imgui.h>



class vars
{
public:
	struct aimbot_t
	{
		bool aimbotEnabled = true;
		bool aimprediction = false;
		float smooth = 4;
		float predictionstrength = 4;
		float delay = 5000;
		float fov = 400;
		float humanizer = 3;
		int aimKey = 46;

		struct drawing_t
		{
			bool fov = true;
			bool line = true;
			bool dot = true;
		} drawing;
	} aimbot;

	struct visuals_t
	{
		bool visualsEnabled = true;
		bool boxEnabled = true;
		bool arrowsEnabled = true;
		bool skeletonEnabled = true;
		bool fovEnabled = true;
		float skeletonespthickness = 2;
		float skelethicknessoutline = 1;
	} visuals;

	struct colors_t
	{
		ImVec4 skeletonColor = { 1, 0, 0, 1 };
		ImVec4 distanceColor = { 1, 1, 1, 1 };
		ImVec4 outlineColor = { 0, 0, 0, 1 };
		ImVec4 boxColor = { 1, 0, 0, 1 };
	} colors;
};

inline std::unique_ptr<vars> g_vars = std::make_unique<vars>();