#pragma once
#include <core/sdk/sdk.hpp>
#include <dependencies/mouse/mouse.h>

namespace closest_player {
	uintptr_t mesh = 0;
}

void aimbot() {
	while (true) {
		if (GetAsyncKeyState(0x02) && util->is_valid(closest_player::mesh) && g_vars->aimbot.aimbotEnabled) {
			uintptr_t boneArray = ioctl.read<uintptr_t>(closest_player::mesh + offsets->BoneArray);
			if (!util->is_valid(boneArray)) continue;
			FTransform componentToWorld = ioctl.read<FTransform>(closest_player::mesh + offsets->ComponentToWorld);

			if (!util->is_valid(boneArray)) boneArray = ioctl.read<uintptr_t>(closest_player::mesh + offsets->BoneArray + 0x10);
			if (!util->is_valid(boneArray)) {
				std::cout << "boneArray issue" << std::endl;
				continue;
			}

			Vector3 headpos = sdk::bone::bone_position(boneArray, 67, componentToWorld);
			Vector2 Headbox = sdk::screen::w2s({ headpos.x, headpos.y, headpos.z + 10 });
			mouse_move(0, (Headbox.x - 960) / g_vars->aimbot.smooth, (Headbox.y - 540) / g_vars->aimbot.smooth, 0);
			//rzctl::mouse_move((Headbox.x - 960) / g_varw->aimbot.smooth, (Headbox.y - 540) / g_varw->aimbot.smooth);
			auto start = std::chrono::high_resolution_clock::now();

			while (true) {
				auto end = std::chrono::high_resolution_clock::now();
				auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
				if (duration.count() >= g_vars->aimbot.delay) {
					break;
				}
			}
		}
	}
}