#pragma once
#include <windows.h>
#include <tlhelp32.h>
#include <iostream>
#include <numbers>
#include <string>
#include <thread>
#include <vector>
#include <mutex>
#include <utility>
#include <unordered_map>
#include <bit>
#include <chrono>

class utilities
{
public:
	const std::uint32_t get_process_id(const std::wstring_view process_name)
	{
		HANDLE handle = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
		DWORD procID = NULL;

		if (handle == INVALID_HANDLE_VALUE)
			return procID;

		PROCESSENTRY32W entry = { 0 };
		entry.dwSize = sizeof(PROCESSENTRY32W);

		if (Process32FirstW(handle, &entry)) {
			if (!_wcsicmp(process_name.data(), entry.szExeFile))
			{
				procID = entry.th32ProcessID;
			}
			else while (Process32NextW(handle, &entry)) {
				if (!_wcsicmp(process_name.data(), entry.szExeFile)) {
					procID = entry.th32ProcessID;
				}
			}
		}

		CloseHandle(handle);
		return procID;
	}

	const bool is_valid(const uintptr_t address)
	{
		if (address <= 0x400000 || address == 0xCCCCCCCCCCCCCCCC || reinterpret_cast<void*>(address) == nullptr || address >
			0x7FFFFFFFFFFFFFFF) {
			return false;
		}
		return true;
	}
};

inline std::unique_ptr<utilities> util = std::make_unique<utilities>();