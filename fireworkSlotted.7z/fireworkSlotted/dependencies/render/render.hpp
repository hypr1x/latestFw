#pragma once
#include <dependencies/render/framework/utilities.hpp>
#include <dependencies/imgui/imgui.h>
#include <dependencies/imgui/imgui_impl_dx11.h>
#include <dependencies/imgui/imgui_impl_win32.h>
#include <dependencies/cipher/hash.hpp>
#include <dependencies/cipher/imports.hpp>
#include <dependencies/render/framework/burbank.hpp>
#include <dwmapi.h>
#include <Uxtheme.h>
#include <d3d11.h>

bool menu = true;
static int current_tab;

typedef HWND(WINAPI* create_window_band_t)(
	_In_ DWORD dwExStyle,
	_In_opt_ ATOM atom,
	_In_opt_ LPCWSTR lpWindowName,
	_In_ DWORD dwStyle,
	_In_ int X,
	_In_ int Y,
	_In_ int nWidth,
	_In_ int nHeight,
	_In_opt_ HWND hWndParent,
	_In_opt_ HMENU hMenu,
	_In_opt_ HINSTANCE hInstance,
	_In_opt_ LPVOID lpParam,
	DWORD band
	);

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace render
{
	class c_render
	{

	public:

		MSG m_msg{ };

		// direct-x 11
		ID3D11Device* m_device{ nullptr };
		IDXGISwapChain* m_swapchain{ nullptr };
		ID3D11DeviceContext* m_device_context{ nullptr };
		ID3D11RenderTargetView* m_target_view{ nullptr };
		//c_render( ) { g_vars->load( ); };

		bool setup(const std::wstring& proc_name);

		std::string get_window_name(HWND window);
		HWND get_window_handle(std::uint32_t pid);

		bool get_screen_status();
		bool get_window();

		bool create_device();
		bool create_target();

		bool create_framework();

		void clean_context();
		void release_objects();

		void tick() noexcept;

		void end_scene();
		void begin_scene();

		void update_cursor()
		{
			ImGuiIO& io = ImGui::GetIO();
			(void)io;

			POINT xy = {};
			ClientToScreen(this->m_window_target, &xy);

			POINT p_cursor;
			GetCursorPos(&p_cursor);

			io.MousePos.x = p_cursor.x - xy.x;
			io.MousePos.y = p_cursor.y - xy.y;

			io.MouseDown[0] = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;

			if (io.MouseDown[0]) {
				io.MouseClicked[0] = true;
				io.MouseClickedPos[0] = io.MousePos;
			}
		}

	public:

		MARGINS m_margin{ -1 };
		RECT m_rect{ };

		std::uint32_t m_pid{ };
		std::string m_name{ };

		HWND m_window_target{ };
		HWND m_overlay{ };

		int m_width{ };
		int m_height{ };

		int m_width_2{ };
		int m_height_2{ };
	};

	inline LRESULT WINAPI WndProc(
		HWND hWnd,
		UINT msg,
		WPARAM wParam,
		LPARAM lParam) {

		if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam)) {
			return true;
		}

		switch (msg)
		{
		case WM_SIZE:
			if (wParam == SIZE_MINIMIZED)
				return 0;
			return 0;
		case WM_SYSCOMMAND:
			if ((wParam & 0xfff0) == SC_KEYMENU)
				return 0;
			break;
		case WM_DESTROY:
			::PostQuitMessage(0);
			return 0;
		}

		return ::DefWindowProcW(hWnd, msg, wParam, lParam);
	}

} inline const auto g_render = std::make_unique<render::c_render>();

const char* key_names[] = {
	"None", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
	"Space", "Enter", "Esc", "Shift", "Ctrl", "Alt", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12",
	"Left Mouse", "Right Mouse", "Middle Mouse", "X1 Mouse", "X2 Mouse"
};

// Corresponding virtual key codes (correct ones for keyboard and mouse)
const int key_codes[] = {
	0, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F, 0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A,
	0x20, 0x0D, 0x1B, 0x10, 0x11, 0x12, 0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F,
	0x01, 0x02, 0x04, 0x05, 0x06 // Mouse buttons
};

auto render::c_render::setup(
	const std::wstring& proc_name) -> bool {

	// nice never free module
	auto user32_dll = LoadLibraryA(hash_str("user32.dll"));
	if (!user32_dll) {
		return false;
	}

	auto create_window_band_p = reinterpret_cast<create_window_band_t>(
import( GetProcAddress )( user32_dll, hash_str( "CreateWindowInBand" ) )
		);

	const auto target_pid = util->get_process_id(proc_name.c_str());
	if (!target_pid) {
		return false;
	}

	const auto game_window_handle = this->get_window_handle(target_pid);
	if (!game_window_handle) {
		return false;
	}

	const auto window_name = this->get_window_name(game_window_handle);
	if (window_name.empty()) {
		return false;
	}

	this->m_pid = std::move(target_pid);
	this->m_name = std::move(window_name);
	this->m_window_target = std::move(game_window_handle);

	const auto get_window = this->get_window();
	if (!get_window) {
		return false;
	}

	WNDCLASSEXW wc = {
		sizeof(wc),
		CS_CLASSDC,
		WndProc,
		0L,
		0L,
		nullptr,
		NULL,
		NULL,
		NULL,
		NULL,
		hash_str(L"ASUS"),
		NULL
	};
	auto res = import(RegisterClassExW)(&wc);

	//enum ZBID
	//{
	//	ZBID_DEFAULT = 0,
	//	ZBID_DESKTOP = 1,
	//	ZBID_UIACCESS = 2,
	//	ZBID_IMMERSIVE_IHM = 3,
	//	ZBID_IMMERSIVE_NOTIFICATION = 4,
	//	ZBID_IMMERSIVE_APPCHROME = 5,
	//	ZBID_IMMERSIVE_MOGO = 6,
	//	ZBID_IMMERSIVE_EDGY = 7,
	//	ZBID_IMMERSIVE_INACTIVEMOBODY = 8,
	//	ZBID_IMMERSIVE_INACTIVEDOCK = 9,
	//	ZBID_IMMERSIVE_ACTIVEMOBODY = 10,
	//	ZBID_IMMERSIVE_ACTIVEDOCK = 11,
	//	ZBID_IMMERSIVE_BACKGROUND = 12,
	//	ZBID_IMMERSIVE_SEARCH = 13,
	//	ZBID_GENUINE_WINDOWS = 14,
	//	ZBID_IMMERSIVE_RESTRICTED = 15,
	//	ZBID_SYSTEM_TOOLS = 16,
	//	ZBID_LOCK = 17,
	//	ZBID_ABOVELOCK_UX = 18,
	//};

	this->m_overlay = create_window_band_p(
		0x00000008L | 0x08000000L | 0x00080000,
		res,
		hash_str(L"Open With"),
		0x80000000L,
		0,
		0,
		this->m_width,
		this->m_height,
		nullptr,
		nullptr,
		nullptr,
		nullptr,
		1 /*ZBID_UIACCESS*/
	);

	if (!this->m_overlay) {
		return false;
	}

	MARGINS margin = { -1 };
	(DwmExtendFrameIntoClientArea)(this->m_overlay, &margin);
import(SetWindowLongA)( this->m_overlay, GWL_EXSTYLE, WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_LAYERED );

import( MoveWindow )( this->m_overlay, 0, 0, this->m_width, this->m_height, false );
import( SetLayeredWindowAttributes )(
	this->m_overlay,
		0,
		0xFF,
		0x02 // LWA_ALPHA
		);

import( ShowWindow )( this->m_overlay, SW_SHOW );
import( UpdateWindow )( this->m_overlay );
	if (false) {
import(SetWindowDisplayAffinity)(this->m_overlay, WDA_EXCLUDEFROMCAPTURE);

	}

	auto status = this->create_device();

	status = this->create_target();

	status = this->create_framework();
	if (!status) {
		return false;
	}

	//print_info( hash_str( "pid: %i\n" ), this->m_pid );
	//print_info( hash_str( "window target: %llx\n" ), this->m_window_target );
	//print_info( hash_str( "window name: %s\n" ), this->m_name.c_str( ) );
	//print_info( hash_str( "width: %i\n" ), this->m_width );
	//print_info( hash_str( "height: %i\n" ), this->m_height );

	return true;
}

auto render::c_render::release_objects() -> void
{
	if (this->m_target_view) {

		this->m_target_view->Release();
		this->m_target_view = nullptr;
	}

	if (this->m_device_context) {

		this->m_device_context->Release();
		this->m_device_context = nullptr;
	}

	if (this->m_device) {

		this->m_device->Release();
		this->m_device = nullptr;
	}

	if (this->m_swapchain) {

		this->m_swapchain->Release();
		this->m_swapchain = nullptr;
	}
}

auto render::c_render::clean_context() -> void
{
	ImGui_ImplDX11_Shutdown();
	ImGui_ImplWin32_Shutdown();
	ImGui::DestroyContext();
import(DestroyWindow)( this->m_overlay );
}

auto render::c_render::get_window() -> bool
{
	auto result = import(GetWindowRect)(
		this->m_window_target,
		&this->m_rect);
	if (!result) {
		return false;
	}

	this->m_width = m_rect.right - m_rect.left;
	this->m_height = m_rect.bottom - m_rect.top;

	this->m_width_2 = m_width / 2;
	this->m_height_2 = m_height / 2;

	return true;
}

auto render::c_render::get_window_name(
	HWND window) -> std::string
{
	wchar_t title[1024];
import( GetWindowTextW )( window, title, 1024 );

	char title_conver[1024];
	std::wcstombs(title_conver, title, 1024);

	return std::string(title_conver);
}

auto render::c_render::get_window_handle(
	std::uint32_t pid) -> HWND
{
	std::pair<HWND, DWORD> params = { 0, pid };

	auto result = import(EnumWindows)([](HWND hwnd, LPARAM lParam) -> int
		{
			auto params = reinterpret_cast<std::pair<HWND, DWORD>*>(lParam);

			DWORD processId;
			if (import(GetWindowThreadProcessId)(hwnd, &processId) && processId == params->second)
			{
				params->first = hwnd;
				return false;
			}

			return true;

		}, reinterpret_cast<LPARAM>(&params));

	if (!result && params.first)
	{
		return params.first;
	}

	return 0;
}

auto render::c_render::get_screen_status() -> bool
{
	if (this->m_window_target == import(GetForegroundWindow).cached()()) {
		return true;
	}

	if (this->m_window_target == import(GetActiveWindow).cached()()) {
		return true;
	}

	if (import(GetActiveWindow).cached()() == import(GetForegroundWindow).cached()()) {
		return true;
	}

	return false;
}

auto render::c_render::create_target() -> bool
{
	ID3D11Texture2D* render_buffer{ nullptr };

	auto result = this->m_swapchain->GetBuffer(
		0,
		__uuidof(ID3D11Texture2D),
		reinterpret_cast<void**>(&render_buffer)
	);
	if (FAILED(result)) {
		return false;
	}

	D3D11_RENDER_TARGET_VIEW_DESC target_desc{ };
	ZeroMemory(&target_desc, sizeof(D3D11_RENDER_TARGET_VIEW_DESC));

	target_desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	target_desc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;

	result = this->m_device->CreateRenderTargetView(
		render_buffer,
		&target_desc,
		&this->m_target_view
	);
	if (FAILED(result)) {
		return false;
	}

	render_buffer->Release();
	return true;
}

auto render::c_render::create_device() -> bool
{
	// refresh rate
	DXGI_RATIONAL refresh_rate{};
	ZeroMemory(&refresh_rate, sizeof(DXGI_RATIONAL));

	refresh_rate.Numerator = 0;
	refresh_rate.Denominator = 1;

	// buffer
	DXGI_MODE_DESC buffer_desc{};
	ZeroMemory(&buffer_desc, sizeof(DXGI_MODE_DESC));

	buffer_desc.Width = this->m_width;
	buffer_desc.Height = this->m_height;
	buffer_desc.RefreshRate = refresh_rate;
	buffer_desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	buffer_desc.ScanlineOrdering = DXGI_MODE_SCANLINE_ORDER_UNSPECIFIED;
	buffer_desc.Scaling = DXGI_MODE_SCALING_UNSPECIFIED;

	// sample 
	DXGI_SAMPLE_DESC sample_desc{};
	ZeroMemory(&sample_desc, sizeof(DXGI_SAMPLE_DESC));

	sample_desc.Count = 1;
	sample_desc.Quality = 0;

	// Swapchain 
	DXGI_SWAP_CHAIN_DESC swapchain_desc{};
	ZeroMemory(&swapchain_desc, sizeof(DXGI_SWAP_CHAIN_DESC));

	swapchain_desc.BufferDesc = buffer_desc;
	swapchain_desc.SampleDesc = sample_desc;
	swapchain_desc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	swapchain_desc.BufferCount = 2;
	swapchain_desc.OutputWindow = this->m_overlay;
	swapchain_desc.Windowed = true;
	swapchain_desc.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
	swapchain_desc.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;

	auto status = D3D11CreateDeviceAndSwapChain(
		nullptr,
		D3D_DRIVER_TYPE_HARDWARE,
		nullptr,
		0,
		nullptr,
		0,
		D3D11_SDK_VERSION,
		&swapchain_desc,
		&this->m_swapchain,
		&this->m_device,
		nullptr,
		&this->m_device_context
	);

	if (FAILED(status)) {
		return false;
	}

	return true;
}
ImFont* burbank;
ImFont* burbank2;
auto render::c_render::create_framework() -> bool
{
	ImGui::CreateContext();

	auto& io = ImGui::GetIO();
	auto& Style = ImGui::GetStyle();
	Style.WindowRounding = 10.f;

	ImVec4* colors = Style.Colors;

	// Main Background
	colors[ImGuiCol_WindowBg] = ImVec4(0 / 255.0f, 0 / 255.0f, 0 / 255.0f, 1.0f); // Dark background

	// Frame Background (widgets like InputText, Slider, etc.)
	colors[ImGuiCol_FrameBg] = ImVec4(4 / 255.0f, 4 / 255.0f, 4 / 255.0f, 1.0f);
	colors[ImGuiCol_FrameBgHovered] = ImVec4(8 / 255.0f, 8 / 255.0f, 8 / 255.0f, 1.0f);
	colors[ImGuiCol_FrameBgActive] = ImVec4(12 / 255.0f, 12 / 255.0f, 12 / 255.0f, 1.0f);

	// Button Colors
	colors[ImGuiCol_Button] = ImVec4(4 / 255.0f, 4 / 255.0f, 4 / 255.0f, 1.0f); // Slightly lighter than background
	colors[ImGuiCol_ButtonHovered] = ImVec4(8 / 255.0f, 8 / 255.0f, 8 / 255.0f, 1.0f); // Highlight on hover
	colors[ImGuiCol_ButtonActive] = ImVec4(12 / 255.0f, 12 / 255.0f, 12 / 255.0f, 1.0f); // Active button

	// Text
	colors[ImGuiCol_Text] = ImVec4(200 / 255.0f, 200 / 255.0f, 200 / 255.0f, 1.0f); // Light gray text
	colors[ImGuiCol_TextDisabled] = ImVec4(100 / 255.0f, 100 / 255.0f, 100 / 255.0f, 1.0f); // Dim text

	// Title Bar
	colors[ImGuiCol_TitleBg] = ImVec4(28 / 255.0f, 28 / 255.0f, 28 / 255.0f, 1.0f);
	colors[ImGuiCol_TitleBgActive] = ImVec4(4 / 255.0f, 4 / 255.0f, 4 / 255.0f, 1.0f);
	colors[ImGuiCol_TitleBgCollapsed] = ImVec4(12 / 255.0f, 12 / 255.0f, 12 / 255.0f, 0.5f);
	colors[ImGuiCol_PopupBg] = ImVec4(1 / 255.0f, 1 / 255.0f, 1 / 255.0f, 1.5f);

	// Scrollbar
	colors[ImGuiCol_ScrollbarBg] = ImVec4(0 / 255.0f, 0 / 255.0f, 0 / 255.0f, 1.0f);
	colors[ImGuiCol_ScrollbarGrab] = ImVec4(22 / 255.0f, 22 / 255.0f, 22 / 255.0f, 1.0f);
	colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(22 / 255.0f, 22 / 255.0f, 22 / 255.0f, 1.0f);
	colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(30 / 255.0f, 30 / 255.0f, 30 / 255.0f, 1.0f);

	// Header (used in tree nodes, etc.)
	colors[ImGuiCol_Header] = ImVec4(4 / 255.0f, 4 / 255.0f, 4 / 255.0f, 1.0f);
	colors[ImGuiCol_HeaderHovered] = ImVec4(22 / 255.0f, 22 / 255.0f, 22 / 255.0f, 1.0f);
	colors[ImGuiCol_HeaderActive] = ImVec4(8 / 255.0f, 8 / 255.0f, 8 / 255.0f, 1.0f);

	// Checkboxes and Radiobuttons
	colors[ImGuiCol_CheckMark] = ImVec4(120 / 255.0f, 180 / 255.0f, 255 / 255.0f, 1.0f); // Blue checkmark

	// Slider
	colors[ImGuiCol_SliderGrab] = ImVec4(30 / 255.0f, 30 / 255.0f, 30 / 255.0f, 1.0f);
	colors[ImGuiCol_SliderGrabActive] = ImVec4(128 / 255.0f, 128 / 255.0f, 128 / 255.0f, 1.0f);

	// Resize Grip
	colors[ImGuiCol_ResizeGrip] = ImVec4(22 / 255.0f, 22 / 255.0f, 22 / 255.0f, 1.0f);
	colors[ImGuiCol_ResizeGripHovered] = ImVec4(8 / 255.0f, 8 / 255.0f, 8 / 255.0f, 1.0f);
	colors[ImGuiCol_ResizeGripActive] = ImVec4(30 / 255.0f, 30 / 255.0f, 30 / 255.0f, 1.0f);

	// Tooltip
	colors[ImGuiCol_PopupBg] = ImVec4(4 / 255.0f, 4 / 255.0f, 4 / 255.0f, 1.0f);

	// Border Colors
	colors[ImGuiCol_Border] = ImVec4(4 / 255.0f, 4 / 255.0f, 4 / 255.0f, 1.0f);
	colors[ImGuiCol_BorderShadow] = ImVec4(0, 0, 0, 0); // No shadow	//burbank = io.Fonts->AddFontFromMemoryTTF(&poppins_medium, sizeof(poppins_medium), 18.0f, 0, io.Fonts->GetGlyphRangesCyrillic());
	//burbank = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\verdanab.ttf", 12.0f, 0, io.Fonts->GetGlyphRangesCyrillic());
	//burbank2 = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\verdanab.ttf", 16.0f, 0, io.Fonts->GetGlyphRangesCyrillic());
	burbank = io.Fonts->AddFontFromMemoryTTF(burbank_font, sizeof(burbank_font), 12.0f, 0, io.Fonts->GetGlyphRangesCyrillic());
	burbank2 = io.Fonts->AddFontFromMemoryTTF(burbank_font, sizeof(burbank_font), 16.0f, 0, io.Fonts->GetGlyphRangesCyrillic());

	auto imgui_win32 = ImGui_ImplWin32_Init(this->m_overlay);
	if (!imgui_win32) {
		return false;
	}

	auto imgui_dx11 = ImGui_ImplDX11_Init(this->m_device, this->m_device_context);
	if (!imgui_dx11) {
		return false;
	}

	return true;
}

auto render::c_render::begin_scene() -> void
{
	ImGui_ImplDX11_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();
}

auto render::c_render::end_scene() -> void
{
	const float color[]{ 0,0,0,0 };

	ImGui::Render();
	ImGui::EndFrame();

	this->m_device_context->OMSetRenderTargets(
		1,
		&this->m_target_view,
		nullptr
	);

	this->m_device_context->ClearRenderTargetView(
		this->m_target_view,
		color
	);

	ImGui_ImplDX11_RenderDrawData(
		ImGui::GetDrawData()
	);

	this->m_swapchain->Present(0, 0);
}