#pragma once
#include <core/sdk/sdk.hpp>
#include <dependencies/render/gui.hpp>

auto render::c_render::tick() noexcept -> void
{
	while (this->m_msg.message != 0x0012)
	{
		if ((PeekMessageA)(&this->m_msg, this->m_overlay, 0, 0, 0x0001))
		{
			TranslateMessage(&this->m_msg);
			DispatchMessageW(&this->m_msg);
		}

		ImGuiIO& io = ImGui::GetIO();

		POINT p_cursor;
		GetCursorPos(&p_cursor);
		ScreenToClient(this->m_overlay, &p_cursor);
		io.MousePos = ImVec2(static_cast<float>(p_cursor.x), static_cast<float>(p_cursor.y));

		io.MouseDown[0] = GetAsyncKeyState(VK_LBUTTON) & 0x8000;
		io.MouseDown[1] = GetAsyncKeyState(VK_RBUTTON) & 0x8000;
		io.MouseDown[2] = GetAsyncKeyState(VK_MBUTTON) & 0x8000;

		if (GetAsyncKeyState(VK_INSERT) & 1)
		{
			menu = !menu;
		}

		this->begin_scene();
		{
			float fps = ImGui::GetIO().Framerate;

			// Prepare the FPS text
			std::string fpsText = "FPS: " + std::to_string(fps);

			for (float dx = -1; dx <= 1; dx = dx + 1 / 2.f) {
				for (float dy = -1; dy <= 1; dy = dy + 1 / 2.f) {
					if (dx != 0 || dy != 0) {
						ImGui::GetBackgroundDrawList()->AddText(
							{ 10, 10 },
							ImGui::GetColorU32(g_vars->colors.outlineColor),
							fpsText.c_str()
						);
					}
				}
			}

			ImGui::GetBackgroundDrawList()->AddText({ 10, 10 }, IM_COL32(255, 255, 255, 255), fpsText.c_str());

			if (this->get_screen_status())
			{
				{
					uintptr_t u_world = ioctl.read<uintptr_t>(ioctl.image_base + offsets->GWorld);
					if (!util->is_valid(u_world)) { std::cout << "u_world " << u_world << std::endl; continue; }

					uintptr_t GameState = ioctl.read<uintptr_t>(u_world + offsets->GameState);
					if (!util->is_valid(GameState)) { std::cout << "GameState " << GameState << std::endl; continue; }


					uintptr_t Gameinstance = ioctl.read<uintptr_t>(u_world + offsets->GameInstance);

					if (!util->is_valid(Gameinstance)) { std::cout << "Gameinstance " << Gameinstance << std::endl; continue; }

					uintptr_t LocalPlayers = ioctl.read<uintptr_t>(Gameinstance + offsets->LocalPlayers);

					if (!util->is_valid(LocalPlayers)) { std::cout << "LocalPlayers " << LocalPlayers << std::endl; continue; }

					uintptr_t Localplayer = ioctl.read<uintptr_t>(LocalPlayers);
					if (!util->is_valid(Localplayer)) continue;

					uintptr_t PlayerController = ioctl.read<uintptr_t>(Localplayer + offsets->PlayerController);
					if (!util->is_valid(PlayerController)) continue;


					uintptr_t LocalPawn = ioctl.read<uintptr_t>(PlayerController + offsets->LocalPawn);

					uintptr_t PlayerArray = ioctl.read<uintptr_t>(GameState + offsets->PlayerArray);
					if (!util->is_valid(PlayerArray)) continue;

					int Num = ioctl.read<int>(GameState + (offsets->PlayerArray + sizeof(uintptr_t)));
					//// std::cout << "Num " << Num << std::endl;
					if (Num < 0 || Num > 300) continue;
					ImGui::PushFont(burbank);
					int lindex = 0;
					uintptr_t lclosestPlayerMesh = 0;
					float lclosest = FLT_MAX;

					TArray<uintptr_t> viewPointState = ioctl.read<TArray<uintptr_t>>(Localplayer + 0xD0);
					uintptr_t ViewState = viewPointState.Get(1);
					auto mProjection = ioctl.read<FMatrix>(ViewState + 0x900);
					viewInfo.rotation.x = RadiansToDegrees(std::asin(mProjection.ZPlane.W));
					viewInfo.rotation.y = RadiansToDegrees(std::atan2(mProjection.YPlane.W, mProjection.XPlane.W));
					viewInfo.rotation.z = 0.0;

					viewInfo.location.x = mProjection.m[3][0];
					viewInfo.location.y = mProjection.m[3][1];
					viewInfo.location.z = mProjection.m[3][2];
					float FieldOfView = atanf(1 / ioctl.read<double>(ViewState + 0x700)) * 2;
					viewInfo.fov = (FieldOfView) * (180.f / m_pi);

					for (uint32_t i = 0; i < Num; i++) {
						uintptr_t player = ioctl.read<uintptr_t>(PlayerArray + i * 0x8);
						if (!util->is_valid(player)) { std::cout << "player " << player << std::endl; continue; }

						uintptr_t playerPrivate = ioctl.read<uintptr_t>(player + offsets->PawnPrivate);
						if (!util->is_valid(playerPrivate)) { /*std::cout << "playerPrivate " << playerPrivate << std::endl;*/ continue; }

						uintptr_t meshes = ioctl.read<uintptr_t>(playerPrivate + offsets->Mesh);
						if (!util->is_valid(meshes)) { std::cout << "meshes " << meshes << std::endl; continue; }

						if (playerPrivate == LocalPawn) continue;

						uintptr_t boneArray = sdk::bone::get_bone_array(meshes);
						if (!util->is_valid(boneArray)) {
							//std::cout << "boneArray issue" << std::endl;
							continue;
						}
						FTransform componentToWorld = ioctl.read<FTransform>(meshes + offsets->ComponentToWorld);


						Vector3 headpos = sdk::bone::bone_position(boneArray, 67, componentToWorld);
						Vector2 Headbox = sdk::screen::w2s({ headpos.x, headpos.y, headpos.z + 15 });

						Vector3 rootpos = sdk::bone::bone_position(boneArray, 0, componentToWorld);
						Vector2 Rootbox = sdk::screen::w2s(rootpos);


						int distance = int(headpos.Distance(viewInfo.location) / 100);
						auto text = ("[") + std::to_string((int)distance) + ("m]");

						auto box_height = abs(Headbox.y - Rootbox.y);
						auto box_width = box_height * 0.45;
						if (g_vars->visuals.visualsEnabled && g_vars->visuals.boxEnabled) {
							ImGui::GetBackgroundDrawList()->AddRect(ImVec2(Headbox.x - box_width / 2, Headbox.y), ImVec2(Headbox.x + box_width / 2, Headbox.y + box_height), ImGui::GetColorU32(g_vars->colors.outlineColor), 0, 0, 2.5f);
							ImGui::GetBackgroundDrawList()->AddRect(ImVec2(Headbox.x - box_width / 2, Headbox.y), ImVec2(Headbox.x + box_width / 2, Headbox.y + box_height), ImGui::GetColorU32(g_vars->colors.boxColor), 0, 0, 1.5f);
						}

						//ImGui::GetBackgroundDrawList()->AddText({ float(Headbox.x), float(Headbox.y) }, ImGui::GetColorU32({ 1, 0, 0, 1 }), text.c_str());


						if (g_vars->visuals.visualsEnabled && g_vars->visuals.arrowsEnabled) {
							auto text_size = ImGui::CalcTextSize(text.c_str()).x;
							auto text_sizey = ImGui::CalcTextSize(text.c_str()).y * 1.0f;
							auto text_center = float(Headbox.x) - text_size * 0.5f;

							for (float dx = -1; dx <= 1; dx = dx + 1 / 2.f) {
								for (float dy = -1; dy <= 1; dy = dy + 1 / 2.f) {
									if (dx != 0 || dy != 0) {
										ImGui::GetBackgroundDrawList()->AddText(
											ImVec2(text_center + dx, float(Rootbox.y) + dy),
											ImGui::GetColorU32(g_vars->colors.outlineColor),
											text.c_str()
										);
									}
								}
							}

							ImGui::GetBackgroundDrawList()->AddText(
								ImVec2(text_center, float(Rootbox.y)),
								ImGui::GetColorU32(g_vars->colors.distanceColor),
								text.c_str()
							);

							text = sdk::text::username(player);
							text_size = ImGui::CalcTextSize(text.c_str()).x;
							text_sizey = ImGui::CalcTextSize(text.c_str()).y * 1.0f;
							text_center = float(Headbox.x) - text_size * 0.5f;

							for (float dx = -1; dx <= 1; dx = dx + 1 / 2.f) {
								for (float dy = -1; dy <= 1; dy = dy + 1 / 2.f) {
									if (dx != 0 || dy != 0) {
										ImGui::GetBackgroundDrawList()->AddText(
											ImVec2(text_center + dx, float(Headbox.y - text_sizey) + dy),
											ImGui::GetColorU32(g_vars->colors.outlineColor),
											text.c_str()
										);
									}
								}
							}

							ImGui::GetBackgroundDrawList()->AddText(
								ImVec2(text_center, float(Headbox.y - text_sizey)),
								ImGui::GetColorU32(g_vars->colors.distanceColor),
								text.c_str()
							);
						}
						if (g_vars->visuals.visualsEnabled && g_vars->visuals.skeletonEnabled) {
							Vector2 allBones[16];
							Vector3 all_bone_pos[16];

							all_bone_pos[0] = sdk::bone::bone_position(boneArray, 67, componentToWorld);
							all_bone_pos[1] = sdk::bone::bone_position(boneArray, 2, componentToWorld);
							all_bone_pos[2] = sdk::bone::bone_position(boneArray, 66, componentToWorld);
							all_bone_pos[3] = sdk::bone::bone_position(boneArray, 9, componentToWorld);
							all_bone_pos[4] = sdk::bone::bone_position(boneArray, 38, componentToWorld);
							all_bone_pos[5] = sdk::bone::bone_position(boneArray, 10, componentToWorld);
							all_bone_pos[6] = sdk::bone::bone_position(boneArray, 39, componentToWorld);
							all_bone_pos[7] = sdk::bone::bone_position(boneArray, 11, componentToWorld);
							all_bone_pos[8] = sdk::bone::bone_position(boneArray, 40, componentToWorld);
							all_bone_pos[9] = sdk::bone::bone_position(boneArray, 78, componentToWorld);
							all_bone_pos[10] = sdk::bone::bone_position(boneArray, 71, componentToWorld);
							all_bone_pos[11] = sdk::bone::bone_position(boneArray, 79, componentToWorld);
							all_bone_pos[12] = sdk::bone::bone_position(boneArray, 72, componentToWorld);
							all_bone_pos[13] = sdk::bone::bone_position(boneArray, 75, componentToWorld);
							all_bone_pos[14] = sdk::bone::bone_position(boneArray, 82, componentToWorld);
							all_bone_pos[15] = sdk::bone::bone_position(boneArray, 0, componentToWorld);

							for (int currentBone = 0; currentBone < 16; currentBone++) {
								Vector3 currentBonePos = all_bone_pos[currentBone];
								allBones[currentBone] = sdk::screen::w2s(currentBonePos);
							}

							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[0].x, allBones[0].y), ImVec2(allBones[2].x, allBones[2].y), ImGui::GetColorU32(g_vars->colors.outlineColor), g_vars->visuals.skeletonespthickness + g_vars->visuals.skelethicknessoutline);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[1].x, allBones[1].y), ImVec2(allBones[2].x, allBones[2].y), ImGui::GetColorU32(g_vars->colors.outlineColor), g_vars->visuals.skeletonespthickness + g_vars->visuals.skelethicknessoutline);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[3].x, allBones[3].y), ImVec2(allBones[2].x, allBones[2].y), ImGui::GetColorU32(g_vars->colors.outlineColor), g_vars->visuals.skeletonespthickness + g_vars->visuals.skelethicknessoutline);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[4].x, allBones[4].y), ImVec2(allBones[2].x, allBones[2].y), ImGui::GetColorU32(g_vars->colors.outlineColor), g_vars->visuals.skeletonespthickness + g_vars->visuals.skelethicknessoutline);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[5].x, allBones[5].y), ImVec2(allBones[3].x, allBones[3].y), ImGui::GetColorU32(g_vars->colors.outlineColor), g_vars->visuals.skeletonespthickness + g_vars->visuals.skelethicknessoutline);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[6].x, allBones[6].y), ImVec2(allBones[4].x, allBones[4].y), ImGui::GetColorU32(g_vars->colors.outlineColor), g_vars->visuals.skeletonespthickness + g_vars->visuals.skelethicknessoutline);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[5].x, allBones[5].y), ImVec2(allBones[7].x, allBones[7].y), ImGui::GetColorU32(g_vars->colors.outlineColor), g_vars->visuals.skeletonespthickness + g_vars->visuals.skelethicknessoutline);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[6].x, allBones[6].y), ImVec2(allBones[8].x, allBones[8].y), ImGui::GetColorU32(g_vars->colors.outlineColor), g_vars->visuals.skeletonespthickness + g_vars->visuals.skelethicknessoutline);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[10].x, allBones[10].y), ImVec2(allBones[1].x, allBones[1].y), ImGui::GetColorU32(g_vars->colors.outlineColor), g_vars->visuals.skeletonespthickness + g_vars->visuals.skelethicknessoutline);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[9].x, allBones[9].y), ImVec2(allBones[1].x, allBones[1].y), ImGui::GetColorU32(g_vars->colors.outlineColor), g_vars->visuals.skeletonespthickness + g_vars->visuals.skelethicknessoutline);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[12].x, allBones[12].y), ImVec2(allBones[10].x, allBones[10].y), ImGui::GetColorU32(g_vars->colors.outlineColor), g_vars->visuals.skeletonespthickness + g_vars->visuals.skelethicknessoutline);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[11].x, allBones[11].y), ImVec2(allBones[9].x, allBones[9].y), ImGui::GetColorU32(g_vars->colors.outlineColor), g_vars->visuals.skeletonespthickness + g_vars->visuals.skelethicknessoutline);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[13].x, allBones[13].y), ImVec2(allBones[12].x, allBones[12].y), ImGui::GetColorU32(g_vars->colors.outlineColor), g_vars->visuals.skeletonespthickness + g_vars->visuals.skelethicknessoutline);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[14].x, allBones[14].y), ImVec2(allBones[11].x, allBones[11].y), ImGui::GetColorU32(g_vars->colors.outlineColor), g_vars->visuals.skeletonespthickness + g_vars->visuals.skelethicknessoutline);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[0].x, allBones[0].y), ImVec2(allBones[2].x, allBones[2].y), ImGui::GetColorU32(g_vars->colors.skeletonColor), g_vars->visuals.skeletonespthickness);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[1].x, allBones[1].y), ImVec2(allBones[2].x, allBones[2].y), ImGui::GetColorU32(g_vars->colors.skeletonColor), g_vars->visuals.skeletonespthickness);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[3].x, allBones[3].y), ImVec2(allBones[2].x, allBones[2].y), ImGui::GetColorU32(g_vars->colors.skeletonColor), g_vars->visuals.skeletonespthickness);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[4].x, allBones[4].y), ImVec2(allBones[2].x, allBones[2].y), ImGui::GetColorU32(g_vars->colors.skeletonColor), g_vars->visuals.skeletonespthickness);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[5].x, allBones[5].y), ImVec2(allBones[3].x, allBones[3].y), ImGui::GetColorU32(g_vars->colors.skeletonColor), g_vars->visuals.skeletonespthickness);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[6].x, allBones[6].y), ImVec2(allBones[4].x, allBones[4].y), ImGui::GetColorU32(g_vars->colors.skeletonColor), g_vars->visuals.skeletonespthickness);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[5].x, allBones[5].y), ImVec2(allBones[7].x, allBones[7].y), ImGui::GetColorU32(g_vars->colors.skeletonColor), g_vars->visuals.skeletonespthickness);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[6].x, allBones[6].y), ImVec2(allBones[8].x, allBones[8].y), ImGui::GetColorU32(g_vars->colors.skeletonColor), g_vars->visuals.skeletonespthickness);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[10].x, allBones[10].y), ImVec2(allBones[1].x, allBones[1].y), ImGui::GetColorU32(g_vars->colors.skeletonColor), g_vars->visuals.skeletonespthickness);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[9].x, allBones[9].y), ImVec2(allBones[1].x, allBones[1].y), ImGui::GetColorU32(g_vars->colors.skeletonColor), g_vars->visuals.skeletonespthickness);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[12].x, allBones[12].y), ImVec2(allBones[10].x, allBones[10].y), ImGui::GetColorU32(g_vars->colors.skeletonColor), g_vars->visuals.skeletonespthickness);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[11].x, allBones[11].y), ImVec2(allBones[9].x, allBones[9].y), ImGui::GetColorU32(g_vars->colors.skeletonColor), g_vars->visuals.skeletonespthickness);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[13].x, allBones[13].y), ImVec2(allBones[12].x, allBones[12].y), ImGui::GetColorU32(g_vars->colors.skeletonColor), g_vars->visuals.skeletonespthickness);
							ImGui::GetBackgroundDrawList()->AddLine(ImVec2(allBones[14].x, allBones[14].y), ImVec2(allBones[11].x, allBones[11].y), ImGui::GetColorU32(g_vars->colors.skeletonColor), g_vars->visuals.skeletonespthickness);
						}

						if (g_vars->visuals.visualsEnabled && g_vars->visuals.arrowsEnabled) {
							float circleRadius = 20 * 10;
							float fCompassSize = circleRadius + 10;

							float cCenterX = 1920 / 2.0f;
							float cCenterY = 1080 / 2.0f;

							float dx = viewInfo.location.x - headpos.x;
							float dy = viewInfo.location.y - headpos.y;

							float Angle = viewInfo.rotation.y / 180 * m_pi;
							float RotateX = -(dy * cosf(Angle) - dx * sinf(Angle));
							float RotateY = (dx * cosf(Angle) + dy * sinf(Angle));

							float angle = atan(RotateX / RotateY) * (180 / m_pi);
							float FinalA = (cCenterY + RotateY / 125.f) > cCenterY ? -angle - 180.0f : -angle;
							if (FinalA < 0) FinalA += 360.0f;

							float radians = (m_pi / 180) * (FinalA - 90.0f);
							float radians1 = (m_pi / 180) * (FinalA - 90.0f + 2.f);
							float radians2 = (m_pi / 180) * (FinalA - 90.0f - 2.f);

							float widthFactor = 0.100f;

							float CircleOutX = cCenterX + (cosf(radians) * (fCompassSize + (fCompassSize / 4.f) * widthFactor));
							float CircleOutY = cCenterY + (sinf(radians) * (fCompassSize + (fCompassSize / 4.f) * widthFactor));
							float CircleOut1X = cCenterX + (cosf(radians1) * (fCompassSize - (fCompassSize / 6.5f) * widthFactor));
							float CircleOut1Y = cCenterY + (sinf(radians1) * (fCompassSize - (fCompassSize / 6.5f) * widthFactor));
							float CircleOut2X = cCenterX + (cosf(radians2) * (fCompassSize - (fCompassSize / 6.5f) * widthFactor));
							float CircleOut2Y = cCenterY + (sinf(radians2) * (fCompassSize - (fCompassSize / 6.5f) * widthFactor));

							ImVec2 vertices[3] = { ImVec2(CircleOutX, CircleOutY), ImVec2(CircleOut1X, CircleOut1Y), ImVec2(CircleOut2X, CircleOut2Y) };

							ImGui::GetForegroundDrawList()->AddTriangleFilled(vertices[0], vertices[1], vertices[2], ImGui::GetColorU32({ 0, 0, 0, 1 }));

							fCompassSize = circleRadius + 10;
							widthFactor = 0.100f;

							CircleOutX = cCenterX + (cosf(radians) * (fCompassSize + (fCompassSize / 5.f) * widthFactor));
							CircleOutY = cCenterY + (sinf(radians) * (fCompassSize + (fCompassSize / 5.f) * widthFactor));
							CircleOut1X = cCenterX + (cosf(radians1) * (fCompassSize - (fCompassSize / 7.5f) * widthFactor));
							CircleOut1Y = cCenterY + (sinf(radians1) * (fCompassSize - (fCompassSize / 7.5f) * widthFactor));
							CircleOut2X = cCenterX + (cosf(radians2) * (fCompassSize - (fCompassSize / 7.5f) * widthFactor));
							CircleOut2Y = cCenterY + (sinf(radians2) * (fCompassSize - (fCompassSize / 7.5f) * widthFactor));

							ImVec2 vertices2[3] = { ImVec2(CircleOutX, CircleOutY), ImVec2(CircleOut1X, CircleOut1Y), ImVec2(CircleOut2X, CircleOut2Y) };

							ImGui::GetForegroundDrawList()->AddTriangleFilled(vertices2[0], vertices2[1], vertices2[2], ImGui::GetColorU32({ 1, 0, 0, 1 }));
						}
						//if (team[i] == localteam) continue;

						int dxa = (Headbox.x - 960);
						int dya = (Headbox.y - 540);
						float dist = sqrtf(dxa * dxa + dya * dya);
						if (dist < 400 && dist < lclosest) {
							lclosestPlayerMesh = meshes;
						}
					}
					closest_player::mesh = lclosestPlayerMesh;
					ImGui::PopFont();
					if (g_vars->visuals.visualsEnabled && g_vars->visuals.fovEnabled)
						ImGui::GetBackgroundDrawList()->AddCircle({ 1920 / 2, 1080 / 2 }, 200, ImGui::GetColorU32({ 1, 1, 1, 1 }), 200, 1.0f);
				}

				ImGui::PushFont(burbank2);
				if (menu) renderGui();

				ImGui::PopFont();

			}
		}

		//ImGui::GetBackgroundDrawList()->AddCircle({ 1920 / 2, 1080 / 2 }, 200, ImGui::GetColorU32(g_vars->colors.outlineColor), 200, 2.5f);

		this->end_scene();
	}

	this->release_objects();
	this->clean_context();

}