#pragma once
#include <iostream>

class offset
{
public:
	static constexpr uintptr_t GWorld = 0x12E8EF68;

	static constexpr uintptr_t GameInstance = 0x1F8;

	static constexpr uintptr_t LocalPlayers = 0x38;

	static constexpr uintptr_t PlayerController = 0x30;

	static constexpr uintptr_t AcknowledgedPawn = 0x350;

	static constexpr uintptr_t PlayerState = 0x2B0;

	static constexpr uintptr_t RootComponent = 0x1B0;

	static constexpr uintptr_t CharacterMovement = 0x318;

	static constexpr uintptr_t LastUpdateVelocity = 0x358;

	static constexpr uintptr_t GameState = 0x180;

	static constexpr uintptr_t Mesh = 0x328;

	static constexpr uintptr_t ComponentToWorld = 0x1c0;

	static constexpr uintptr_t PawnPrivate = 0x320;

	static constexpr uintptr_t LocalPawn = 0x350;

	static constexpr uintptr_t PlayerArray = 0x2C0;

	static constexpr uintptr_t TeamIndex = 0x1239;

	static constexpr uintptr_t HabaneroComponent = 0xa10;

	static constexpr uintptr_t KillScore = 0x1224;

	static constexpr uintptr_t bIsDying = 0x6f0;

	static constexpr uintptr_t bIsDBNO = 0x93A;

	static constexpr uintptr_t bIsABot = 0x29a;

	static constexpr uintptr_t CurrentVehicle = 0x29A0;

	static constexpr uintptr_t CurrentWeapon = 0x9f8;

	static constexpr uintptr_t WeaponData = 0x568;

	static constexpr uintptr_t ItemName = 0x40;

	static constexpr uintptr_t BoneArray = 0x580;

	static constexpr uintptr_t BoneCached = 0x5B8;

	static constexpr uintptr_t TargetedFortPawn = 0x18A8;

	static constexpr uintptr_t Velocity = 0x168;
};

inline std::unique_ptr<offset> offsets = std::make_unique<offset>();