#pragma once

#include <Windows.h>
#include <TlHelp32.h>
#include <cstdint>
#include <vector>
#include <chrono>
#include <thread>
#include <iostream>

#define code_read CTL_CODE(FILE_DEVICE_UNKNOWN, 0xAA6D1, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define code_write CTL_CODE(FILE_DEVICE_UNKNOWN, 0xAA6D2, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define code_image CTL_CODE(FILE_DEVICE_UNKNOWN, 0xAA6D3, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define code_cr3 CTL_CODE(FILE_DEVICE_UNKNOWN, 0xAA6D4, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define code_mouse CTL_CODE(FILE_DEVICE_UNKNOWN, 0xAA6D5, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)

typedef struct _read_invoke {
	INT32 process_id;
	ULONGLONG address;
	ULONGLONG buffer;
	ULONGLONG size;
} read_invoke, * pread_invoke;

typedef struct _write_invoke {
	INT32 process_id;
	ULONGLONG address;
	ULONGLONG buffer;
	ULONGLONG size;
} write_invoke, * pwrite_invoke;

typedef struct _image_invoke {
	INT32 process_id;
	ULONGLONG* address;
} image_invoke, * pimage_invoke;

typedef struct _mouse_invoke {
	LONG x;
	LONG y;
	unsigned short button_flags;
} mouse_invoke, * pmouse_invoke;

typedef struct _dtb_invoke {
	uint32_t        pid;
	uintptr_t       cr3;
} dtb_invoke, * pdtb_invoke;

class _ioctl
{
public:
	HANDLE driver_handle;
	INT32 process_id;
	uintptr_t cr3;

	__int64 text_section_base = 0;

	uintptr_t image_base;


	bool start_service() {
		driver_handle = CreateFileW(L"\\\\.\\{16cdc545-fe80-45f4-b75c-a0e052d17596}",
			GENERIC_READ | GENERIC_WRITE,
			FILE_SHARE_READ | FILE_SHARE_WRITE,
			NULL,
			OPEN_EXISTING,
			0,
			NULL);

		if (driver_handle == INVALID_HANDLE_VALUE)
		{
			printf("Failed to open driver handle\n");
			return false;
		}

		return true;
	}


	void read_physical(PVOID address, PVOID buffer, DWORD size) {
		_read_invoke data = { 0 };

		data.address = (ULONGLONG)address;
		data.buffer = (ULONGLONG)buffer;
		data.size = size;
		data.process_id = process_id;

		// Assuming 'code_read' is a valid control code for read operations
		DeviceIoControl(driver_handle, code_read, &data, sizeof(data), nullptr, 0, nullptr, nullptr);
		//std::cout << data. << std::endl;
	}

	void write_physical(PVOID address, PVOID buffer, DWORD size) {
		_write_invoke data = { 0 };

		data.address = (ULONGLONG)address;
		data.buffer = (ULONGLONG)buffer;
		data.size = size;
		data.process_id = process_id;

		// Assuming 'code_write' is a valid control code for write operations
		DeviceIoControl(driver_handle, code_write, &data, sizeof(data), nullptr, 0, nullptr, nullptr);
	}

	bool get_dtb() {
		cr3 = 0;
		_dtb_invoke data = { 0 };

		data.pid = process_id;
		data.cr3 = (uintptr_t)&cr3;

		DeviceIoControl(driver_handle, code_cr3, &data, sizeof(data), nullptr, 0, nullptr, nullptr);

		return cr3;
	}

	uintptr_t get_image() {
		image_base = 0;
		_image_invoke data = { 0 };

		data.process_id = process_id;
		data.address = (ULONGLONG*)&image_base;

		DeviceIoControl(driver_handle, code_image, &data, sizeof(data), nullptr, 0, nullptr, nullptr);

		return image_base;
	}

	INT32 attach(LPCTSTR process_name) {
		PROCESSENTRY32 pt;
		HANDLE hsnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
		pt.dwSize = sizeof(PROCESSENTRY32);
		if (Process32First(hsnap, &pt)) {
			do {
				if (!lstrcmpi(pt.szExeFile, process_name)) {
					CloseHandle(hsnap);
					process_id = pt.th32ProcessID;
					return pt.th32ProcessID;
				}
			} while (Process32Next(hsnap, &pt));
		}
		CloseHandle(hsnap);

		return { NULL };
	}

	template <typename T>
	T read(uint64_t address) {
		T buffer{ };
		read_physical((PVOID)address, &buffer, sizeof(T));
		return buffer;
	}

	template <typename T>
	T write(uint64_t address, T buffer) {
		write_physical((PVOID)address, &buffer, sizeof(T));
		return buffer;
	}

	template <typename t>
	auto read_array(const uintptr_t address, t buffer, size_t size) -> bool
	{
		read_physical((PVOID)address, buffer, size);

		return true;
	}
};

inline _ioctl ioctl;